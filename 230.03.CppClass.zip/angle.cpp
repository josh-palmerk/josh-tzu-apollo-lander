/***********************************************************************
 * Source:
 *    Angle 
 * Summary:
 *    Just call the Angle unit tests
 * Author:
 *    James Helfrich
 ************************************************************************/

#include "testAngle.h"

/************************************
 * MAIN
 * Simple driver
 ***********************************/
int main()
{
   TestAngle().run();

   return 0;
}
